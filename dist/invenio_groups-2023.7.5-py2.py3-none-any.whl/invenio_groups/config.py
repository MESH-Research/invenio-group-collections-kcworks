GROUP_COLLECTIONS_REMOTE_ROLES = {
    "knowledgeCommons": ["administrator", "member", "moderator"],
}

GROUP_COLLECTIONS_METADATA_ENDPOINTS = {
    "knowledgeCommons": "https://hcommons-dev.org/wp-json/commons/v1/groups",
}
