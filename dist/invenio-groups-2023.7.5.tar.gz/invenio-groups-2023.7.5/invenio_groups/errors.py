class CommonsGroupNotFoundError(Exception):
    pass
