..
    Copyright (C) 2023 MESH Research

    invenio-groups is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

Social groups infrastructure for InvenioRDM

- MESH Research <scottia4@msu.edu>