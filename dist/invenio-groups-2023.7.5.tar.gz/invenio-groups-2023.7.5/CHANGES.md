# Changes

Version 2023.06.07

- Initial public release.