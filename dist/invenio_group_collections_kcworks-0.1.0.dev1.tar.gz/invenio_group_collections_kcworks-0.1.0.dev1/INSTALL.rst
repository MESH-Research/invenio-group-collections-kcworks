Installation
============

invenio-group-collections-kcworks is not on PyPI so you need to install it from GitHub:

.. code-block:: console

   $ pip install git+https://github.com/MESH-Research/invenio-group-collections-kcworks.git