..
    Copyright (C) 2024 MESH Research

    invenio-group-collections-kcworksis free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

Collections administered by remote social groups for InvenioRDM

- MESH Research <scottia4@msu.edu>